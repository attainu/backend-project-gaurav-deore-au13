module.exports={
    'secret':'redrider',
    'user' : 'rohitbilung.nalanda@gmail.com',
    'password' : 'ROHIT22MARCH'
}